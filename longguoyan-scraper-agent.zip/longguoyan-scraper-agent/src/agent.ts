import { agent, tool, Sandbox } from "@21st-sdk/agent"
import { z } from "zod"

// ─── Tool: Fetch Page ─────────────────────────────────────────────────────────

const fetchPageTool = tool({
  description: "Fetch the HTML content of a URL and return it as text",
  inputSchema: z.object({
    url: z.string().describe("The URL to fetch"),
  }),
  execute: async ({ url }) => {
    const res = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; LongguoyanScraper/1.0)",
        Accept: "text/html,application/xhtml+xml",
      },
    })
    const html = await res.text()
    return { content: [{ type: "text", text: html }] }
  },
})

// ─── Tool: Parse Product List ─────────────────────────────────────────────────

const parseProductListTool = tool({
  description:
    "Parse the product listing HTML from longguoyan.com and return all product links and thumbnail images",
  inputSchema: z.object({
    html: z.string().describe("Raw HTML of the product listing page"),
  }),
  execute: async ({ html }) => {
    const linkRe = /href="(\/product\/12\/\d+\.html)"/g
    const imgRe =
      /<a href="(\/product\/12\/\d+\.html)"[^>]*>\s*<img[^>]+src="([^"]+)"/g

    const products: { url: string; thumb: string }[] = []
    const seen = new Set<string>()
    const imgMap: Record<string, string> = {}
    let m

    while ((m = imgRe.exec(html)) !== null) {
      imgMap[m[1]] = m[2]
    }
    while ((m = linkRe.exec(html)) !== null) {
      const path = m[1]
      if (!seen.has(path)) {
        seen.add(path)
        products.push({
          url: "https://longguoyan.com" + path,
          thumb: imgMap[path] ? "https://longguoyan.com" + imgMap[path] : "",
        })
      }
    }

    return { content: [{ type: "text", text: JSON.stringify(products) }] }
  },
})

// ─── Tool: Parse Product Detail ───────────────────────────────────────────────

const parseProductDetailTool = tool({
  description:
    "Parse a product detail page HTML and extract name, description, and all image URLs",
  inputSchema: z.object({
    html: z.string(),
    url: z.string(),
  }),
  execute: async ({ html, url }) => {
    const titleMatch =
      html.match(/<h3[^>]*>([\s\S]*?)<\/h3>/) ||
      html.match(/<title>([\s\S]*?)-贵州龙国宴酒业有限公司<\/title>/)
    const name = titleMatch
      ? titleMatch[1].replace(/<[^>]+>/g, "").trim()
      : "Unknown"

    const images: string[] = []
    let m

    const imgRe =
      /src="(https?:\/\/longguoyan\.com\/upload\/ueditor\/image\/[^"]+\.(?:jpg|jpeg|png|webp))"/gi
    while ((m = imgRe.exec(html)) !== null) {
      if (!images.includes(m[1])) images.push(m[1])
    }

    const img2Re =
      /src="(https?:\/\/longguoyan\.com\/_\d+\/[^"]+\.(?:jpg|jpeg|png|webp))"/gi
    while ((m = img2Re.exec(html)) !== null) {
      if (!images.includes(m[1])) images.push(m[1])
    }

    const descMatch = html.match(
      /<div[^>]*class="[^"]*content[^"]*"[^>]*>([\s\S]*?)<\/div>/i
    )
    const description = descMatch
      ? descMatch[1].replace(/<[^>]+>/g, "").trim().slice(0, 500)
      : ""

    return {
      content: [
        { type: "text", text: JSON.stringify({ name, url, images, description }) },
      ],
    }
  },
})

// ─── Tool: Translate ──────────────────────────────────────────────────────────

const translateTool = tool({
  description:
    "Translate an array of Chinese product names and descriptions into English",
  inputSchema: z.object({
    texts: z.array(
      z.object({
        key: z.string(),
        text: z.string(),
      })
    ),
  }),
  execute: async ({ texts }) => {
    const apiKey = process.env.ANTHROPIC_API_KEY ?? ""

    const prompt =
      `Translate the following Chinese liquor product names/descriptions to English.\n` +
      `Rules:\n` +
      `- Keep the brand name "龙国宴" as "Longguoyan"\n` +
      `- Be concise and accurate\n` +
      `- Return ONLY a JSON array: [{"key":"...","translated":"..."}]\n` +
      `- No extra text, no markdown fences\n\n` +
      texts.map((t) => `key: ${t.key}\ntext: ${t.text}`).join("\n\n")

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": apiKey,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: "claude-haiku-4-5-20251001",
          max_tokens: 1024,
          messages: [{ role: "user", content: prompt }],
        }),
      })

      const data = await res.json()
      const raw = data.content?.[0]?.text ?? "[]"
      const jsonMatch = raw.match(/\[[\s\S]*\]/)
      const translations = jsonMatch ? JSON.parse(jsonMatch[0]) : []
      return { content: [{ type: "text", text: JSON.stringify(translations) }] }
    } catch {
      // If translation fails, return originals unchanged
      const fallback = texts.map((t) => ({ key: t.key, translated: t.text }))
      return { content: [{ type: "text", text: JSON.stringify(fallback) }] }
    }
  },
})

// ─── Tool: Download Images ────────────────────────────────────────────────────

const downloadImagesTool = tool({
  description:
    "Download all product images to /home/user/images/<product-folder>/, one folder per product",
  inputSchema: z.object({
    products: z.array(
      z.object({
        nameEn: z.string().describe("English product name (used for folder name)"),
        images: z.array(z.string()).describe("Image URLs to download"),
      })
    ),
  }),
  execute: async ({ products }) => {
    const { mkdirSync, writeFileSync, existsSync } = await import("fs")
    const base = "/home/user/images"
    if (!existsSync(base)) mkdirSync(base, { recursive: true })

    const results: {
      product: string
      folder: string
      downloaded: string[]
      failed: string[]
    }[] = []

    for (const product of products) {
      const folderName = product.nameEn
        .replace(/[^a-zA-Z0-9\s\-]/g, "")
        .trim()
        .replace(/\s+/g, "-")
        .toLowerCase()
        .slice(0, 60)

      const productDir = `${base}/${folderName}`
      if (!existsSync(productDir)) mkdirSync(productDir, { recursive: true })

      const downloaded: string[] = []
      const failed: string[] = []

      for (const imgUrl of product.images) {
        try {
          const res = await fetch(imgUrl, {
            headers: { "User-Agent": "Mozilla/5.0 (compatible; LongguoyanScraper/1.0)" },
          })
          if (!res.ok) throw new Error(`HTTP ${res.status}`)

          const buffer = await res.arrayBuffer()
          const filename = imgUrl.split("/").pop()?.split("?")[0] ?? `img_${Date.now()}.jpg`
          const filepath = `${productDir}/${filename}`
          writeFileSync(filepath, Buffer.from(buffer))
          downloaded.push(filepath)
        } catch {
          failed.push(imgUrl)
        }
      }

      results.push({ product: product.nameEn, folder: productDir, downloaded, failed })
    }

    const totalOk = results.reduce((n, r) => n + r.downloaded.length, 0)
    const totalFail = results.reduce((n, r) => n + r.failed.length, 0)

    return {
      content: [
        {
          type: "text",
          text:
            `Downloaded ${totalOk} images (${totalFail} failed).\n` +
            `Base folder: /home/user/images/\n\n` +
            JSON.stringify(results, null, 2),
        },
      ],
    }
  },
})

// ─── Tool: Save Results ───────────────────────────────────────────────────────

const saveResultsTool = tool({
  description: "Save the final product catalog (with translations + local image paths) as JSON",
  inputSchema: z.object({
    products: z.array(
      z.object({
        nameZh: z.string(),
        nameEn: z.string(),
        descriptionZh: z.string(),
        descriptionEn: z.string(),
        url: z.string(),
        images: z.array(z.string()),
        localImages: z.array(z.string()),
      })
    ),
  }),
  execute: async ({ products }) => {
    const { writeFileSync } = await import("fs")
    const json = JSON.stringify(products, null, 2)
    writeFileSync("/home/user/longguoyan_products.json", json, "utf-8")

    const totalImages = products.reduce((n, p) => n + p.localImages.length, 0)

    const summary = products
      .map(
        (p) =>
          `• ${p.nameEn} / ${p.nameZh}\n` +
          `  ${p.localImages.length} images saved · ${p.url}`
      )
      .join("\n")

    return {
      content: [
        {
          type: "text",
          text:
            `✓ Saved ${products.length} products · ${totalImages} images total\n` +
            `File: /home/user/longguoyan_products.json\n` +
            `Images: /home/user/images/\n\n` +
            summary,
        },
      ],
    }
  },
})

// ─── Agent ────────────────────────────────────────────────────────────────────

export default agent({
  model: "claude-sonnet-4-6",
  runtime: "claude-code",
  permissionMode: "bypass-all",
  maxTurns: 150,

  systemPrompt: `You are a product scraping agent for longguoyan.com (贵州龙国宴酒业有限公司 — Maotang Liquor / Guizhou Longguoyan Liquor Co.).

Execute these steps in order. Do not skip any.

STEP 1 — Fetch the product listing page:
  fetchPage({ url: "https://longguoyan.com/product.html" })

STEP 2 — Parse all product URLs from that HTML:
  parseProductList({ html: <result> })

STEP 3 — For EACH product URL, fetch and parse the detail page:
  fetchPage({ url: <product url> })
  parseProductDetail({ html: <result>, url: <product url> })

STEP 4 — Translate all Chinese names and descriptions to English in one batch call:
  translate({
    texts: [
      { key: "p0-name", text: "<Chinese name>" },
      { key: "p0-desc", text: "<Chinese description>" },
      ... (all products)
    ]
  })
  Rule: always render "龙国宴" as "Longguoyan".

STEP 5 — Download all images, organized by English product name:
  downloadImages({
    products: [
      { nameEn: "<English name>", images: ["<url>", ...] },
      ...
    ]
  })

STEP 6 — Save the final combined dataset:
  saveResults({
    products: [
      {
        nameZh: "<original Chinese>",
        nameEn: "<translated English>",
        descriptionZh: "<original>",
        descriptionEn: "<translated>",
        url: "<product page URL>",
        images: ["<remote url>", ...],
        localImages: ["<local /home/user/images/... path>", ...]
      },
      ...
    ]
  })

STEP 7 — Report the final summary clearly to the user.`,

  tools: {
    fetchPage: fetchPageTool,
    parseProductList: parseProductListTool,
    parseProductDetail: parseProductDetailTool,
    translate: translateTool,
    downloadImages: downloadImagesTool,
    saveResults: saveResultsTool,
  },

  sandbox: Sandbox({
    cwd: "/home/user",
    build: ["mkdir -p /home/user/images"],
    setup: ["echo 'Agent ready'"],
  }),

  onFinish: async ({ result }) => {
    console.log("[done]", result?.stopReason)
  },
})
