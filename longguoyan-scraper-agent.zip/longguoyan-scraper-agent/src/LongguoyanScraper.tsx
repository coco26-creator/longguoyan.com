"use client"

// app/components/LongguoyanScraper.tsx
// Drop this into any Next.js 14+ app (App Router)
// Requires: npm install @21st-sdk/nextjs ai @ai-sdk/react

import { useChat } from "@ai-sdk/react"
import { Chat, DefaultChatTransport } from "ai"
import { useState } from "react"

interface Product {
  name: string
  url: string
  images: string[]
  description: string
}

export default function LongguoyanScraper() {
  const [products, setProducts] = useState<Product[]>([])
  const [running, setRunning] = useState(false)
  const [sandboxId, setSandboxId] = useState<string | undefined>()

  const chat = new Chat({
    transport: new DefaultChatTransport({
      api: "/api/an/chat",          // your token-exchange proxy route
      body: { sandboxId },
      headers: async () => {
        const res = await fetch("/api/an/token")
        const { token } = await res.json()
        return { Authorization: `Bearer ${token}` }
      },
    }),
  })

  const { messages, append, status } = useChat({
    chat,
    onResponse: (response) => {
      const sid = response.headers.get("x-sandbox-id")
      if (sid) setSandboxId(sid)
    },
    onFinish: (message) => {
      // Try to parse product JSON from the agent's last message
      try {
        const jsonMatch = message.content.match(/\[[\s\S]*\]/)
        if (jsonMatch) {
          const parsed = JSON.parse(jsonMatch[0])
          if (Array.isArray(parsed) && parsed[0]?.name) {
            setProducts(parsed)
          }
        }
      } catch {}
      setRunning(false)
    },
  })

  const startScrape = () => {
    setRunning(true)
    setProducts([])
    append({
      role: "user",
      content:
        "Scrape all products and images from https://longguoyan.com/product.html. Return the full product list as JSON at the end.",
    })
  }

  const downloadJSON = () => {
    const blob = new Blob([JSON.stringify(products, null, 2)], {
      type: "application/json",
    })
    const a = document.createElement("a")
    a.href = URL.createObjectURL(blob)
    a.download = "longguoyan_products.json"
    a.click()
  }

  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: "2rem", fontFamily: "sans-serif" }}>
      <h1 style={{ fontSize: 22, fontWeight: 500, marginBottom: 8 }}>
        Longguoyan Product Scraper
      </h1>
      <p style={{ color: "#666", marginBottom: 24, fontSize: 14 }}>
        Powered by 21st Agent · longguoyan.com
      </p>

      <div style={{ display: "flex", gap: 12, marginBottom: 24 }}>
        <button
          onClick={startScrape}
          disabled={running}
          style={{
            padding: "8px 20px",
            borderRadius: 8,
            border: "1px solid #ddd",
            background: running ? "#f5f5f5" : "#000",
            color: running ? "#999" : "#fff",
            cursor: running ? "not-allowed" : "pointer",
            fontSize: 14,
          }}
        >
          {running ? "Scraping..." : "Scrape all products"}
        </button>

        {products.length > 0 && (
          <button
            onClick={downloadJSON}
            style={{
              padding: "8px 20px",
              borderRadius: 8,
              border: "1px solid #ddd",
              background: "#fff",
              cursor: "pointer",
              fontSize: 14,
            }}
          >
            Download JSON ({products.length} products)
          </button>
        )}
      </div>

      {/* Agent log */}
      {messages.length > 0 && (
        <div
          style={{
            background: "#f9f9f9",
            borderRadius: 8,
            padding: "12px 16px",
            marginBottom: 24,
            fontSize: 12,
            fontFamily: "monospace",
            maxHeight: 180,
            overflowY: "auto",
            border: "1px solid #eee",
          }}
        >
          {messages
            .filter((m) => m.role === "assistant")
            .slice(-1)
            .map((m) => (
              <div key={m.id} style={{ whiteSpace: "pre-wrap", color: "#333" }}>
                {typeof m.content === "string"
                  ? m.content.slice(0, 600)
                  : ""}
              </div>
            ))}
          {running && (
            <div style={{ color: "#999", marginTop: 4 }}>● running…</div>
          )}
        </div>
      )}

      {/* Product grid */}
      {products.length > 0 && (
        <>
          <h2 style={{ fontSize: 16, fontWeight: 500, marginBottom: 16 }}>
            {products.length} products found ·{" "}
            {products.reduce((n, p) => n + p.images.length, 0)} images total
          </h2>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))",
              gap: 16,
            }}
          >
            {products.map((p) => (
              <div
                key={p.url}
                style={{
                  border: "1px solid #eee",
                  borderRadius: 12,
                  overflow: "hidden",
                  background: "#fff",
                }}
              >
                {p.images[0] && (
                  <img
                    src={p.images[0]}
                    alt={p.name}
                    style={{
                      width: "100%",
                      height: 180,
                      objectFit: "cover",
                      display: "block",
                    }}
                  />
                )}
                <div style={{ padding: "12px" }}>
                  <p style={{ fontSize: 13, fontWeight: 500, marginBottom: 4 }}>
                    {p.name}
                  </p>
                  <p style={{ fontSize: 11, color: "#999", marginBottom: 6 }}>
                    {p.images.length} image{p.images.length !== 1 ? "s" : ""}
                  </p>
                  <a
                    href={p.url}
                    target="_blank"
                    rel="noreferrer"
                    style={{ fontSize: 11, color: "#0066cc" }}
                  >
                    View product →
                  </a>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
