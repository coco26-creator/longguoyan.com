// app/api/an/token/route.ts
// Next.js App Router — server-side token exchange
// This keeps your AN_API_KEY secret on the server

import { NextResponse } from "next/server"

export async function GET() {
  const apiKey = process.env.AN_API_KEY
  if (!apiKey) {
    return NextResponse.json({ error: "AN_API_KEY not set" }, { status: 500 })
  }

  // Exchange long-lived API key for a short-lived JWT the client can use
  const res = await fetch("https://relay.an.dev/v1/auth/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
  })

  if (!res.ok) {
    return NextResponse.json({ error: "Token exchange failed" }, { status: 500 })
  }

  const { token } = await res.json()
  return NextResponse.json({ token })
}
