# Longguoyan Product Scraper — 21st Agent

A 21st Agent that scrapes all products and images from
longguoyan.com (贵州龙国宴酒业有限公司).

## What it does

1. Fetches https://longguoyan.com/product.html
2. Parses all product links
3. Visits each product detail page
4. Extracts: product name, URL, all image URLs, description
5. Saves results to `/home/user/longguoyan_products.json` in the sandbox
6. Returns a full summary

## Project structure

```
longguoyan-scraper-agent/
├── package.json
└── src/
    ├── agent.ts              ← 21st Agent config (deploy this)
    ├── LongguoyanScraper.tsx ← React component for your Next.js app
    └── token-route.ts        ← Next.js API route for token exchange
```

## Setup & Deploy

### 1. Install dependencies
```bash
npm install
```

### 2. Login to 21st
```bash
npx @21st-sdk/cli login
# Enter your API key from https://21st.dev/agents/api
```

### 3. Deploy the agent
```bash
npx @21st-sdk/cli deploy
# Output: https://api.an.dev/v1/chat/longguoyan-scraper-agent
```

### 4. Add to your Next.js app

Copy `LongguoyanScraper.tsx` into your `app/components/` folder.

Copy `token-route.ts` to `app/api/an/token/route.ts`.

Add your API key to `.env.local`:
```
AN_API_KEY=an_sk_your_key_here
```

Install client dependencies:
```bash
npm install @21st-sdk/nextjs ai @ai-sdk/react
```

Use the component anywhere:
```tsx
import LongguoyanScraper from "@/components/LongguoyanScraper"

export default function Page() {
  return <LongguoyanScraper />
}
```

## Output format

The agent saves and returns JSON like:
```json
[
  {
    "name": "龙国宴酒·窖藏九五至尊30",
    "url": "https://longguoyan.com/product/12/51.html",
    "images": [
      "https://longguoyan.com/upload/ueditor/image/20250407/1744016218488933.jpg",
      "https://longguoyan.com/upload/ueditor/image/20250407/1744016218703531.jpg"
    ],
    "description": ""
  }
]
```

## Tools used by the agent

| Tool | What it does |
|------|-------------|
| `fetchPage` | Fetches any URL and returns raw HTML |
| `parseProductList` | Parses listing page → product links + thumbs |
| `parseProductDetail` | Parses detail page → name, images, description |
| `saveResults` | Writes final JSON to the sandbox filesystem |

## Notes

- `permissionMode: "bypass-all"` — no confirmation prompts, runs fully autonomous
- `maxTurns: 100` — enough for ~10 products × ~5 tool calls each
- The agent uses `WebFetch` (built-in) + custom tools for parsing
- Re-deploy to pick up site changes: `npx @21st-sdk/cli deploy`
